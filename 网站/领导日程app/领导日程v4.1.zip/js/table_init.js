Table().init({
    id:'table',
    header:['姓名','周一','周二','周三','周四','周五'],
    data:[
       ['','上午','下午']
    ],
    columnWidth:2
});

$(".wdwz").click(function(){
    $(this).find(".user-link-tab-childs").slideToggle("act");
    $(this).find('.fa').toggleClass("fa-rotate-180");
});
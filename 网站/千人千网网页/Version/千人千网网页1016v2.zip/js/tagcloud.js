var data = [
	{name: "水利部", weight: 17, url:"http://mwr.gov.cn/"},
	{name: "每日水雨情", weight: 16, url:"http://mwr.gov.cn/"},
	{name: "地方水利", weight: 13, url:"http://mwr.gov.cn/"},
	{name: "水利新闻", weight: 18, url:"http://mwr.gov.cn/"},
	{name: "水利政策", weight: 29, url:"http://mwr.gov.cn/"},
	{name: "项目资质", weight: 13, url:"http://mwr.gov.cn/"},
	{name: "地方河流政策", weight: 10, url:"http://mwr.gov.cn/"},
	{name: "河道信息", weight: 18, url:"http://mwr.gov.cn/"},
	{name: "工程违规举报", weight: 23, url:"http://mwr.gov.cn/"},
	{name: "湖泊分布信息", weight: 14, url:"http://mwr.gov.cn/"},
	{name: "国家法规", weight: 16, url:"http://mwr.gov.cn/"},
	{name: "水利部", weight: 17, url:"http://mwr.gov.cn/"},
	{name: "每日水雨情", weight: 16, url:"http://mwr.gov.cn/"},
	{name: "地方水利", weight: 13, url:"http://mwr.gov.cn/"},
	{name: "水利新闻", weight: 18, url:"http://mwr.gov.cn/"},
	{name: "项目资质", weight: 13, url:"http://mwr.gov.cn/"},
	{name: "地方河流政策", weight: 10, url:"http://mwr.gov.cn/"},
	{name: "河道信息", weight: 18, url:"http://mwr.gov.cn/"},
	{name: "工程违规举报", weight: 23, url:"http://mwr.gov.cn/"},
	{name: "水利政策", weight: 20, url:"http://mwr.gov.cn/"},
	{name: "湖泊分布信息", weight: 14, url:"http://mwr.gov.cn/"},
	{name: "国家法规", weight: 16, url:"http://mwr.gov.cn/"},
	
	]
	Highcharts.chart('img', {
		chart: {
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			type: 'wordcloud',
			height: 200,
			margin: [0,0,10,0]

		},tooltip: {
			enabled: false
		},
		plotOptions: {
            series: {
                cursor: 'pointer',
                point: {
                    events: {
                        click: function(e) {
                            location.href = this.options.url;
                            // location.href = e.point.url
                            // location.href = window.open(e.point.url)
                        }
                    }
                }
            }
        },
	series: [{
		data: data,
		name: '我的关键字',
		rotation: {
			from: 0,
		to: 0
		},
		spiral: 'rectangular',
		placementStrategy: 'center'
	}],
	colors: ['#92c1ff', '#fbd34b', '#a9e979', '#66decf', '#5acb78', '#975fe4'],
	title: {
		text: null
	},
	credits: {
		// 去除logo
		enabled: false,
	},
	});
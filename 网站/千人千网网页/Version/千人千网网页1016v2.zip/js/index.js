// 首页文章加载
var data_img = "";
var data_notice = "";
var data_news = "";
    jQuery.ajax({
        type: "get",
        url: "http://www.mwr.gov.cn/syxg/tpxw/qrqwIndex.js",
        dataType: "jsonp",
        jsonp: "callback",
        jsonpCallback: "qrqwIndex",
        success: function (result) {
            if (result && result.length > 0) {
                result.forEach(function (cv) {
                    if (cv.name === "data_img") {
                        cv.data.forEach(function (v) {
                            data_img += "<div class=\"slick-item\"><a href='"+v.url+"' title='"+v.title+"'><img src='"+v.img+"' alt='' width='403' height='227'><div class=\"tit1\">"+v.title+"</div></a></div>";
                        });
                        $('.slick-mod').append(data_img);
                        $(".slick-mod").slick({
                            dots: false,
                            autoplay: true,
                        });
                        console.log(data_img)
                    } else if (cv.name === "data_notice") {
                        cv.data.forEach(function (v) {
                            data_notice += "<li><a href=\"" + v.url + "\" title='"+v.title+"'>●&nbsp;&nbsp;" + v.title + "</a></li>"
                        });
                        $('#data_notice').append(data_notice);
                    } else if(cv.name === "data_news") {
                        cv.data.forEach(function (v) {
                            data_news += "<li><a href=\"" + v.url + "\" title='"+v.title+"'>●&nbsp;&nbsp;" + v.title + "<span class=\"fr\">"+v.date+"</span></a></li>"
                        });
                        $('#data_news').append(data_news);
                    }
                })
            }
        }
    });
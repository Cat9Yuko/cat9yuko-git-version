$(".wdwz").click(function(event){
    
    $(this).next(".user-link-tab-childs").stop().slideToggle("act");
    $(this).find('.fa').stop().toggleClass("fa-flip-vertical");
    event.stopPropagation();
});


// 我的收藏选项卡
$(".check-title").click(function () {
    $(this).next().stop().slideToggle("act");
    $(this).find(".fa").toggleClass("fa-flip-vertical");
});
$(".tree-c span").click(function () {
    $(this).addClass("act").siblings().removeClass("act");
    // alert($(this).index());
    $(".tree-ch").eq($(this).index()).addClass("act").siblings().removeClass("act");
});
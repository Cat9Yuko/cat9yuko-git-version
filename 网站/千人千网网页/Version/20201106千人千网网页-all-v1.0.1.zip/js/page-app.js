// 我的收藏选项卡
$(".check-title").click(function (event) {
    // event.
    $(this).next().stop().slideToggle("act");
});